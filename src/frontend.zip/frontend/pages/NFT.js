import React,{useState,useEffect} from 'react'
import { ethers } from "ethers"
import Song from './spotify components/Song'
import { useStore } from '../store/StoreContext';
import { buyNFT, resellNFT } from '../contract scripts/nftTransactions';
import { getArtist, getArtistContract } from '../contract scripts/artist';
import { useLocation } from 'react-router-dom';

function NFT() {
  const { state: item} = useLocation()
  console.log(item)
  const {marketContract,account,signer}=useStore()
  const [artist,setArtist]=useState(null)
  const location=useLocation()
  const isResell=item.owner.toLowerCase()===ethers.constants.AddressZero.toLowerCase()?false:true;
  console.log(item.owner)
  console.log(account)
  const isAction=isResell || (item.owner.toLowerCase()===account.toLowerCase())
  const getStatus=()=>{
    if (!isResell && isAction)
          return 'My Item'
    if(isResell)
          return 'On Sale'
    else return 'Purchased item'
  }
  const status=getStatus();
  const loadArtist=async()=>{
    const artistContract=await getArtistContract(marketContract,item.artist,signer)
    console.log(artistContract)
    const artist1=await getArtist(artistContract)
    console.log(artist1)
    setArtist(artist1)
  }
  useEffect(()=>{
    !artist&&loadArtist()
  })
  const buyItemFunction=async(artistAddress,tokenId,tokenPrice)=>{
    await buyNFT(marketContract,artistAddress,tokenId,tokenPrice)
  }
  const resellItemFunction=async(artistAddress,tokenId,newTokenPrice,artistFee)=>{
    await resellNFT(marketContract,artistAddress,tokenId,newTokenPrice,artistFee)
  }
  const action=isResell?resellItemFunction:buyItemFunction;

  return (
    <Song item={item} isOnSell={!isResell} action={action} artist={artist} isAction={isAction} status={status} />
  )
}

export default NFT