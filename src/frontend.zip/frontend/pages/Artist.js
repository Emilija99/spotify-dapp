import React, { useState,useEffect } from 'react'
import { useStore } from '../store/StoreContext'
import { getItemsByArtist, getTokensWithMetadata, getUnsoldItemsByArtist } from '../contract scripts/nftQueries.js';
import ContentSection from './spotify components/ContentSection';
import { useLocation,useParams } from 'react-router-dom';

function Artist({artistAdd='',artistName=''}) {
  const location=useLocation()
  const {artistId}=useParams();
  const artistAddress=artistAdd===''?artistId:artistAdd;
  const context=useStore();
  const marketContract=context.marketContract;
  const artist=context.artist;
  const [items,setItems]=useState([])
  //const title=artist.address===artistAddress?'NFT Music Tokens created by me':'NFT Music Tokens created by: '+artistName
  const fetchItems=async()=>{
    let tokens=[]
    if(context.isArtist &&(artist.address.toLowerCase()===artistAddress.toLowerCase()))
    
      
        tokens=await getItemsByArtist(artist.contract)
    
    else
    
        tokens=await getUnsoldItemsByArtist(marketContract,artistAddress,context.signer)
    
    let songs=await getTokensWithMetadata(tokens)
    songs=songs.map((item)=>({...item,link:'/artist/'+artistAddress+'/'+item.itemId}))
    setItems(songs)
  }
  useEffect(()=>{items.length===0&&fetchItems()})
  return (
    <ContentSection title='Tokens' data={items} />
  )
}

export default Artist