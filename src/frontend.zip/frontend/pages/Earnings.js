import React,{useState} from 'react'
import { useEffect } from 'react';
import DataTable from 'react-data-table-component';
import { useStore } from '../store/StoreContext';
import { getIncomeEvents } from '../contract scripts/eventQueries';
import { ethers } from 'ethers';
import { Link } from 'react-router-dom';
import './Earnings.scss'
function Earnings() {
  const [events,setEvents]=useState([])
  const {marketContract,account,signer}=useStore()
  const [loaded,setLoaded]=useState(false)
  const loadEvents=async()=>{
        const eventss=await getIncomeEvents(marketContract,account,signer);
        console.log(eventss)
        setEvents(eventss)
        setLoaded(true)
  }
  const convertTimestampToString=(timestamp)=>{
    const date=new Date(timestamp*1000);
    const string=`Date: ${date.getDate()}/${date.getMonth()+1}/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`
    return string
  }
  const customStyles={
    headCells:{
      style:{
        backgroundColor:'rgba(166,136,136,1)',
        fontWeight:'bolder'
      }
    }
  }
  const columns=[{
    name:'Event',
    cell:row=>(<div>{row.type==='resale'?'Your token is listed on resell by another user so  you receive your artist fee':'Your token was purchased by another user'
  }</div>)},{
    name:'Time of transaction',
    selector:row=>convertTimestampToString(row.timestamp)
  },{
    name:'Amount of ETH you earned',
    selector:row=>`$${ethers.utils.formatEther(row.value)}ETH`
  },{
    name:'Transaction',
    cell:row=>(
        <Link to={`https://sepolia.etherscan.io/tx/${row.transactionHash}`} target='_blank'>{row.transactionHash}</Link>
    )
  },
  {
    name:'Link to token involved',
    cell:row=>(
        <Link to={`/artist/${row.artist}/${row.tokenId}`} >{row.transactionHash}</Link>
    )
  }
]
  useEffect(()=>{
    !loaded &&loadEvents()
  },)
  return (
   <div className='eCont'>
    <h3>Your earnings</h3>
    <DataTable
    theme='dark'
    columns={columns}
    data={events}
    striped={false}
    customStyles={customStyles}
    
/>
</div>
  )
}

export default Earnings