import React from 'react'

const MyResales=()=>{
    return(
        <div>

        </div>
    );
    
};
export default MyResales;